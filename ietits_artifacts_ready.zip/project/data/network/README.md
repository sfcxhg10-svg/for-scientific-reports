# Network Datasets (IET-ITS Preparation)

This folder contains two ready-to-use networks for simulation and evaluation:

1) **grid20x20**: Regular grid (20x20), spacing 100 m, arterial corridors every 5th row/column.
2) **city_clip**: Pseudo-OSM city clip with irregular spacing, some edge removals, and added diagonals to mimic real structures.

Each network includes:
- `nodes.csv` / `edges.csv` / `signals.csv` with standardized columns.
- `plain.nod.xml` / `plain.edg.xml` in SUMO "plain" format.

## Build SUMO nets
Use `netconvert` (from SUMO) to convert plain files to a SUMO net:
```
netconvert -n plain.nod.xml -e plain.edg.xml -o net.net.xml
```
You can then create routes and run simulations as usual.

## Column definitions
- **nodes.csv**: `node_id, x_lon, y_lat, type`  (type: regular/signal)
- **edges.csv**: `edge_id, from_node, to_node, length_m, lanes, speed_kph, capacity_vehph, is_signalized`
- **signals.csv**: `junction_id, phase_id, g_s, y_s, r_s, cycle_s, lanes_allowed`

Units: time in seconds, speed in kph, length in meters, capacity in vehicles/hour.

