# Grid20x20 Network

- Grid size: 20 x 20
- Spacing: 100.0 m
- Anchor (lat, lon): (34.26, 108.94)

## Files
- nodes.csv / edges.csv / signals.csv
- plain.nod.xml / plain.edg.xml  (SUMO plain format)

## Build a SUMO net (example command)
netconvert -n plain.nod.xml -e plain.edg.xml -o net.net.xml

(If you wish to infer traffic lights from nodes of type="traffic_light", SUMO will create TLS automatically.)
