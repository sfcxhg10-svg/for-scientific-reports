# City Clip (Pseudo-OSM) Network

- Grid (irregular) size: 12 x 12
- Nominal spacing: 120.0 m with randomness
- Anchor (lat, lon): (34.25, 108.95)
- Edge removal probability: 0.12
- Added diagonals: True

## Files
- nodes.csv / edges.csv / signals.csv
- plain.nod.xml / plain.edg.xml (SUMO plain format)

## Build a SUMO net (example command)
netconvert -n plain.nod.xml -e plain.edg.xml -o net.net.xml

(SUMO will treat nodes with type="traffic_light" as TLS.)
