# SUMO Batch Runner

This folder contains a ready-to-use batch runner for SUMO experiments.

## Prerequisites
- SUMO tools in PATH: `netconvert`, `duarouter`, `sumo` (or `sumo-gui`).
- Data are under `../../data/...`, incidents under `../../data/incidents/...`.

## Typical workflow
```bash
# 1) Build networks
python batch.py build_net --network grid20x20
python batch.py build_net --network city_clip

# 2) Build routes for normal/peak
python batch.py build_routes --network grid20x20 --traffic normal
python batch.py build_routes --network grid20x20 --traffic peak
python batch.py build_routes --network city_clip --traffic normal
python batch.py build_routes --network city_clip --traffic peak

# 3) Run one case (normal traffic, scenario S1, given seed)
python batch.py run --network grid20x20 --traffic normal --scenario S1 --seed 123

# 4) Run all seeds from ../../seeds.txt
python batch.py run_all --network city_clip --traffic peak --scenario S1 --seeds_file ../../seeds.txt
```

Outputs (tripinfo.xml, summary.xml, kpi.csv) are written to:
`../../results/<network>/<traffic>/<scenario>/seed_<seed>/`

### Notes
- Scenario S1 applies **full closure** via `<rerouter><closingReroute>...` in an additional file.
- Scenario S2 entries are parsed but **capacity reduction is not applied** by default (requires TraCI or editing net parameters). You can extend `batch.py` to dynamically change edge speeds/lanes.
- Trips are mapped from node pairs to a pair of edges (outgoing from origin, incoming to destination), then routed via `duarouter`.
