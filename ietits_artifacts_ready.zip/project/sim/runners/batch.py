#!/usr/bin/env python3
"""
SUMO batch runner for two networks (grid20x20, city_clip).

What it does (no internet needed, SUMO required in PATH):
1) Build SUMO net from plain.nod.xml / plain.edg.xml (netconvert).
2) Convert CSV trips to <trip> and run duarouter to compute .rou.xml.
3) Create incident additional files:
   - S1: full closure of one arterial edge during [start,end].
   - S2: capacity drop is approximated via speed reduction (optional, needs TraCI or pre-edited net; here we skip by default and only close if closure==1).
4) Generate a .sumocfg per (network, traffic_mode, scenario, seed).
5) Run sumo (or sumo-gui) and export tripinfo.xml and summary.xml.
6) Parse outputs to CSV KPIs (mean trip time, total travel time, throughput).

Usage examples:
    python batch.py build_net --network grid20x20
    python batch.py build_routes --network grid20x20 --traffic normal
    python batch.py make_cfg --network grid20x20 --traffic normal --scenario S1 --seed 123
    python batch.py run --network grid20x20 --traffic normal --scenario S1 --seed 123
    python batch.py run_all --network grid20x20 --traffic normal --scenario S1 --seeds_file ../../seeds.txt

Requirements:
- SUMO tools in PATH: netconvert, duarouter, sumo
- Data folders are expected at ../../data/...
"""

import argparse
import csv
import os
import sys
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, ElementTree
import subprocess
import statistics as stats

ROOT = Path(__file__).resolve().parents[2]   # /project
NET_ROOT = ROOT / "data" / "network"
DEM_ROOT = ROOT / "data" / "demand"
INC_ROOT = ROOT / "data" / "incidents"
OUT_ROOT = ROOT / "results"

def run_cmd(cmd):
    print("[RUN]", " ".join(cmd), flush=True)
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(proc.stdout)
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}")
    return proc

def build_net(network):
    net_dir = NET_ROOT / network
    out_net = net_dir / "net.net.xml"
    cmd = ["netconvert", "-n", str(net_dir / "plain.nod.xml"), "-e", str(net_dir / "plain.edg.xml"), "-o", str(out_net)]
    run_cmd(cmd)
    return out_net

def read_edges(network):
    with open(NET_ROOT / network / "edges.csv", newline="", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        return list(rdr)

def read_trips_csv(network, traffic):
    path = DEM_ROOT / network / f"trips_{traffic}.csv"
    with open(path, newline="", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        return list(rdr)

def pick_from_to_edges(edges, o_node, d_node):
    # select an outgoing edge from o_node, and an incoming edge to d_node
    out_edges = [e for e in edges if e["from_node"] == o_node]
    in_edges  = [e for e in edges if e["to_node"] == d_node]
    if not out_edges or not in_edges:
        return None, None
    # choose shortest length for determinism
    out_e = sorted(out_edges, key=lambda x: float(x["length_m"]))[0]
    in_e  = sorted(in_edges, key=lambda x: float(x["length_m"]))[0]
    return out_e["edge_id"], in_e["edge_id"]

def make_trips_xml(network, traffic, trips, edges):
    out_dir = NET_ROOT / network
    trips_xml = out_dir / f"trips_{traffic}.xml"
    root = Element("trips")
    for row in trips:
        veh_id = row["veh_id"]
        dep    = row["dep_time_s"]
        o_node = row["o_node"]
        d_node = row["d_node"]
        from_e, to_e = pick_from_to_edges(edges, o_node, d_node)
        if from_e is None or to_e is None:
            # skip trips that cannot be mapped
            continue
        SubElement(root, "trip", id=veh_id, depart=dep, frm=from_e, to=to_e, type="car")
    ElementTree(root).write(trips_xml, encoding="utf-8", xml_declaration=True)
    return trips_xml

def build_routes(network, traffic):
    net_path = NET_ROOT / network / "net.net.xml"
    if not net_path.exists():
        build_net(network)
    edges = read_edges(network)
    trips = read_trips_csv(network, traffic)
    trips_xml = make_trips_xml(network, traffic, trips, edges)
    # run duarouter to compute routes
    rou_xml = NET_ROOT / network / f"routes_{traffic}.rou.xml"
    cmd = ["duarouter", "-n", str(net_path), "-t", str(trips_xml), "-o", str(rou_xml), "--ignore-errors"]
    run_cmd(cmd)
    return rou_xml

def make_incidents_add(network, scenario_id):
    # incidents.csv: scenario_id, edge_id, start_s, end_s, capacity_factor, closure, description
    inc_path = INC_ROOT / network / "incidents.csv"
    if not inc_path.exists():
        return None
    rows = []
    with open(inc_path, newline="", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        for r in rdr:
            if r["scenario_id"] == scenario_id:
                rows.append(r)
    if not rows:
        return None
    # build additional with rerouter closing (for closure==1)
    add = Element("additional")
    for i, r in enumerate(rows, 1):
        edge = r["edge_id"]
        start = r["start_s"]; end = r["end_s"]
        closure = int(r["closure"])
        if closure == 1:
            rr = SubElement(add, "rerouter", id=f"rr_{scenario_id}_{i}", edges=edge)
            iv = SubElement(rr, "interval", begin=start, end=end)
            SubElement(iv, "closingReroute", id=edge)
        else:
            # capacity_factor < 1 is not applied here (needs TraCI or edited net to reduce lanes/speed).
            # We still write a comment for clarity.
            SubElement(add, "vType", id=f"note_{i}", vClass="passenger")  # harmless placeholder
    out_add = NET_ROOT / network / f"incidents_{scenario_id}.add.xml"
    ElementTree(add).write(out_add, encoding="utf-8", xml_declaration=True)
    return out_add

def make_cfg(network, traffic, scenario, seed):
    net = NET_ROOT / network / "net.net.xml"
    if not net.exists():
        build_net(network)
    rou = NET_ROOT / network / f"routes_{traffic}.rou.xml"
    if not rou.exists():
        build_routes(network, traffic)
    add = make_incidents_add(network, scenario)
    cfg = Element("configuration")
    input_el = SubElement(cfg, "input")
    SubElement(input_el, "net-file", value=str(net))
    SubElement(input_el, "route-files", value=str(rou))
    if add is not None:
        SubElement(input_el, "additional-files", value=str(add))
    time_el = SubElement(cfg, "time")
    SubElement(time_el, "begin", value="0")
    SubElement(time_el, "end", value="3600")
    out_dir = OUT_ROOT / network / traffic / scenario / f"seed_{seed}"
    out_dir.mkdir(parents=True, exist_ok=True)
    report_el = SubElement(cfg, "report")
    SubElement(report_el, "verbose", value="true")
    SubElement(report_el, "no-step-log", value="true")
    out_el = SubElement(cfg, "output")
    SubElement(out_el, "summary-output", value=str(out_dir / "summary.xml"))
    SubElement(out_el, "tripinfo-output", value=str(out_dir / "tripinfo.xml"))
    cfg_path = out_dir / "run.sumocfg"
    ElementTree(cfg).write(cfg_path, encoding="utf-8", xml_declaration=True)
    return cfg_path

def run_once(network, traffic, scenario, seed, sumo_bin="sumo"):
    cfg = make_cfg(network, traffic, scenario, seed)
    cmd = [sumo_bin, "-c", str(cfg)]
    run_cmd(cmd)
    # Parse KPIs from tripinfo.xml
    tripinfo = cfg.parent / "tripinfo.xml"
    mean_tt, total_tt, trips = parse_tripinfo(tripinfo)
    kpi_csv = cfg.parent / "kpi.csv"
    with open(kpi_csv, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f); wr.writerow(["mean_trip_time_s","total_travel_time_s","trips"])
        wr.writerow([f"{mean_tt:.2f}", f"{total_tt:.2f}", trips])
    print(f"[OK] KPIs written to {kpi_csv}")
    return kpi_csv

def parse_tripinfo(path):
    # Lightweight parser (avoid heavy XML libs)
    # We search for attributes duration="..."
    import re
    pat = re.compile(r'duration="([\d\.]+)"')
    durations = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            m = pat.search(line)
            if m:
                durations.append(float(m.group(1)))
    if not durations:
        return 0.0, 0.0, 0
    mean_tt = sum(durations)/len(durations)
    total_tt = sum(durations)
    return mean_tt, total_tt, len(durations)

def run_all(network, traffic, scenario, seeds_file, sumo_bin="sumo"):
    with open(seeds_file, encoding="utf-8") as f:
        seeds = [int(x.strip()) for x in f if x.strip()]
    out_rows = []
    for s in seeds:
        try:
            kpi_csv = run_once(network, traffic, scenario, s, sumo_bin=sumo_bin)
            with open(kpi_csv, newline="", encoding="utf-8") as f:
                rdr = csv.DictReader(f)
                row = next(rdr)
                out_rows.append([s, float(row["mean_trip_time_s"]), float(row["total_travel_time_s"]), int(row["trips"])])
        except Exception as e:
            print("[WARN] run failed for seed", s, ":", e)
    # aggregate
    agg_dir = ROOT / "results" / network / traffic / scenario
    agg_dir.mkdir(parents=True, exist_ok=True)
    agg_csv = agg_dir / "kpi_agg.csv"
    with open(agg_csv, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f); wr.writerow(["seed","mean_trip_time_s","total_travel_time_s","trips"])
        wr.writerows(out_rows)
    print("[DONE] Aggregated KPIs:", agg_csv)

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("build_net")
    p1.add_argument("--network", required=True)

    p2 = sub.add_parser("build_routes")
    p2.add_argument("--network", required=True)
    p2.add_argument("--traffic", choices=["normal","peak"], required=True)

    p3 = sub.add_parser("make_cfg")
    p3.add_argument("--network", required=True)
    p3.add_argument("--traffic", choices=["normal","peak"], required=True)
    p3.add_argument("--scenario", choices=["S1","S2"], required=True)
    p3.add_argument("--seed", type=int, required=True)

    p4 = sub.add_parser("run")
    p4.add_argument("--network", required=True)
    p4.add_argument("--traffic", choices=["normal","peak"], required=True)
    p4.add_argument("--scenario", choices=["S1","S2"], required=True)
    p4.add_argument("--seed", type=int, required=True)
    p4.add_argument("--sumo-bin", default="sumo")

    p5 = sub.add_parser("run_all")
    p5.add_argument("--network", required=True)
    p5.add_argument("--traffic", choices=["normal","peak"], required=True)
    p5.add_argument("--scenario", choices=["S1","S2"], required=True)
    p5.add_argument("--seeds_file", default=str(ROOT / "seeds.txt"))
    p5.add_argument("--sumo-bin", default="sumo")

    args = ap.parse_args()

    if args.cmd == "build_net":
        build_net(args.network)
    elif args.cmd == "build_routes":
        build_routes(args.network, args.traffic)
    elif args.cmd == "make_cfg":
        make_cfg(args.network, args.traffic, args.scenario, args.seed)
    elif args.cmd == "run":
        run_once(args.network, args.traffic, args.scenario, args.seed, sumo_bin=args.sumo_bin)
    elif args.cmd == "run_all":
        run_all(args.network, args.traffic, args.scenario, args.seeds_file, sumo_bin=args.sumo_bin)

if __name__ == "__main__":
    main()
