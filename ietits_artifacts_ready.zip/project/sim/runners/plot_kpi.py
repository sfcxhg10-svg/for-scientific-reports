#!/usr/bin/env python3
"""
plot_kpi.py
Reads kpi_agg.csv under project/results/<network>/<traffic>/<scenario>/
and generates three figure types per (network, traffic):
  1) ECDF (mean_trip_time_s) comparing scenarios S1 vs S2  -> fig4_ecdf_<net>_<traffic>.svg
  2) Boxplot (mean_trip_time_s)                            -> fig5_box_<net>_<traffic>.svg
  3) Bar with 95% CI (mean_trip_time_s)                    -> fig5_bar_<net>_<traffic>.svg

Notes:
- Uses matplotlib only; one chart per figure; no explicit colors set.
- If a kpi_agg.csv is missing for a scenario, that scenario is skipped.
"""

import os
import csv
import math
from pathlib import Path
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]  # /project
RES_DIR = ROOT / "results"
FIG_DIR = RES_DIR / "figs"
FIG_DIR.mkdir(parents=True, exist_ok=True)

NETWORKS = ["grid20x20", "city_clip"]
TRAFFICS = ["normal", "peak"]
SCENARIOS = ["S1", "S2"]

def read_kpi_agg(path: Path):
    vals = []
    if not path.exists():
        return vals
    with open(path, newline="", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        for row in rdr:
            try:
                vals.append(float(row["mean_trip_time_s"]))
            except Exception:
                pass
    return vals

def ecdf(x):
    xs = sorted(x)
    n = len(xs)
    if n == 0:
        return [], []
    ys = [(i+1)/n for i in range(n)]
    return xs, ys

def save_ecdf(net, traffic, data_by_scn):
    if not any(len(v)>0 for v in data_by_scn.values()):
        return None
    plt.figure(figsize=(6,4.5))
    for scen in ["S1","S2"]:
        x = data_by_scn.get(scen, [])
        if len(x) == 0: 
            continue
        xs, ys = ecdf(x)
        plt.step(xs, ys, where="post", label=scen)
    plt.xlabel("Mean trip time (s)")
    plt.ylabel("ECDF")
    plt.title(f"ECDF of Mean Trip Time — {net}, {traffic}")
    plt.legend(loc="lower right")
    out = FIG_DIR / f"fig4_ecdf_{net}_{traffic}.svg"
    plt.tight_layout()
    plt.savefig(out, format="svg")
    plt.close()
    return out

def save_box(net, traffic, data_by_scn):
    labels = []
    series = []
    for scen in ["S1","S2"]:
        x = data_by_scn.get(scen, [])
        if len(x)>0:
            labels.append(scen)
            series.append(x)
    if not series:
        return None
    plt.figure(figsize=(6,4.5))
    plt.boxplot(series, labels=labels, showmeans=True)
    plt.ylabel("Mean trip time (s)")
    plt.title(f"Boxplot — {net}, {traffic}")
    out = FIG_DIR / f"fig5_box_{net}_{traffic}.svg"
    plt.tight_layout()
    plt.savefig(out, format="svg")
    plt.close()
    return out

def save_bar_ci(net, traffic, data_by_scn):
    labels = []
    means = []
    cis = []
    for scen in ["S1","S2"]:
        x = data_by_scn.get(scen, [])
        if len(x)>0:
            labels.append(scen)
            m = sum(x)/len(x)
            # 95% CI (normal approx): 1.96 * s / sqrt(n)
            if len(x) > 1:
                mu = m
                var = sum((xi-mu)**2 for xi in x)/(len(x)-1)
                se = (var**0.5)/ (len(x)**0.5)
                ci95 = 1.96 * se
            else:
                ci95 = 0.0
            means.append(m)
            cis.append(ci95)
    if not labels:
        return None
    plt.figure(figsize=(6,4.5))
    xs = range(len(labels))
    plt.bar(xs, means)
    # error bars
    for i, (x, m, ci) in enumerate(zip(xs, means, cis)):
        plt.errorbar([x], [m], yerr=[ci], fmt='none', capsize=4)
    plt.xticks(xs, labels)
    plt.ylabel("Mean trip time (s)")
    plt.title(f"Mean ± 95% CI — {net}, {traffic}")
    out = FIG_DIR / f"fig5_bar_{net}_{traffic}.svg"
    plt.tight_layout()
    plt.savefig(out, format="svg")
    plt.close()
    return out

def main():
    generated = []
    for net in NETWORKS:
        for traffic in TRAFFICS:
            data_by_scn = {}
            for scen in SCENARIOS:
                path = RES_DIR / net / traffic / scen / "kpi_agg.csv"
                data_by_scn[scen] = read_kpi_agg(path)
            p1 = save_ecdf(net, traffic, data_by_scn)
            p2 = save_box(net, traffic, data_by_scn)
            p3 = save_bar_ci(net, traffic, data_by_scn)
            for p in (p1,p2,p3):
                if p is not None:
                    generated.append(str(p))
    # Write an index file listing generated figures
    idx = FIG_DIR / "PLOTS_INDEX.txt"
    with open(idx, "w", encoding="utf-8") as f:
        for g in generated:
            f.write(g + "\n")

if __name__ == "__main__":
    main()
