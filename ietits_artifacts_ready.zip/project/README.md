# IET-ITS Repro Bundle

This package contains **two networks**, **all input CSV/YAML**, **incident scenarios**, **behavior settings**, **seeds/configs**, **SUMO batch runner**, and **example KPIs & figures** matching the paper’s Fig-3–Fig-5 (synthetic placeholders).

## Folder layout
```
project/
  data/
    network/
      grid20x20/   # 20x20 grid, with nodes.csv, edges.csv, signals.csv, plain.nod.xml, plain.edg.xml
      city_clip/    # pseudo-OSM clip (irregular), same files as above
    demand/
      grid20x20/ {trips_normal.csv, trips_peak.csv, zones.csv, od_*.csv, trips_TEMPLATE.csv}
      city_clip/  {trips_normal.csv, trips_peak.csv, zones.csv, od_*.csv, trips_TEMPLATE.csv}
    incidents/
      grid20x20/incidents.csv
      city_clip/incidents.csv
    behavior/
      <net>/compliance.csv, latency.csv
  baselines/baselines.yaml
  sim/runners/
    batch.py      # main runner (build_net, build_routes, run, run_all)
    README.md
  results/
    <net>/<traffic>/<scenario>/seed_<seed>/kpi.csv   # synthetic example KPIs
    <net>/<traffic>/<scenario>/kpi_agg.csv          # aggregated KPIs per setting
    figs/ fig3.svg, fig4.svg, fig5.svg              # example figures
  seeds.txt
  compute.yaml
  paramsweep.yaml
  README.md (this file)
```

## Quick start
1. **Prerequisites**: SUMO tools in PATH (`netconvert`, `duarouter`, `sumo` or `sumo-gui`).  
2. **Build networks** (once per net):
   ```bash
   cd project/sim/runners
   python batch.py build_net --network grid20x20
   python batch.py build_net --network city_clip
   ```
3. **Build routes** from trips:
   ```bash
   python batch.py build_routes --network grid20x20 --traffic normal
   python batch.py build_routes --network grid20x20 --traffic peak
   python batch.py build_routes --network city_clip --traffic normal
   python batch.py build_routes --network city_clip --traffic peak
   ```
4. **Run experiments** (single seed or batch):
   ```bash
   # single run (normal, S1 closure)
   python batch.py run --network grid20x20 --traffic normal --scenario S1 --seed 123

   # run all seeds listed in ../../seeds.txt
   python batch.py run_all --network city_clip --traffic peak --scenario S1 --seeds_file ../../seeds.txt
   ```
   Outputs are written to `project/results/<net>/<traffic>/<scenario>/seed_<seed>/`.

## Notes
- The packaged `kpi.csv` / `kpi_agg.csv` are **synthetic placeholders** consistent with the example figures.  
  After running on your machine with SUMO, these CSVs will be overwritten with **real results**; the figure files can then be re-generated accordingly.
- Scenario **S1** applies **full closure** via additional file (`closingReroute`).  
  Scenario **S2** is included for capacity drops (requires TraCI or net edits to realize capacity_factor<1; the current runner demonstrates closure only).
- Units: time in seconds, speed in kph, length in meters, capacity in vehicles/hour.

## Tips for the paper
- Use **grid20x20** for ablations; **city_clip** for main results and robustness (adoption, latency, estimation error).
- Keep `seeds.txt`, `compute.yaml`, `paramsweep.yaml` with your submission to ease replication.
